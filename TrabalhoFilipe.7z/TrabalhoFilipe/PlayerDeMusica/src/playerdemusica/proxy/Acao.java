package playerdemusica.proxy;

public interface Acao {
    public void executar();
}
