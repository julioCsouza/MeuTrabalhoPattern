package playerdemusica.tamplate;

public class Cd extends GravarMusica{

    @Override
    void gravarMusica() {
        System.out.println("Gravando musicas em um CD.");
    }
    
}
