package playerdemusica.tamplate;

public class Pendrive extends GravarMusica{

    @Override
    void gravarMusica() {
        System.out.println("Gravar musicas em um PENDRIVE.");
    }
    
}
