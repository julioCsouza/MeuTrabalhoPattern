package playerdemusica.composity;

public interface MusicaComposity {
    public String getNome();
}
