package playerdemusica.state;


public class MusicaEmReproducao implements EstadoDaMusica{

    @Override
    public void EstadoDaMusica() {
        System.out.println("Musica esta sendo reproduzida");
    }
}
