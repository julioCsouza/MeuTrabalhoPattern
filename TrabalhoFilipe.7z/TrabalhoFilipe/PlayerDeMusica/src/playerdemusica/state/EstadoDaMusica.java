package playerdemusica.state;

public interface EstadoDaMusica {
    public void EstadoDaMusica();
}
