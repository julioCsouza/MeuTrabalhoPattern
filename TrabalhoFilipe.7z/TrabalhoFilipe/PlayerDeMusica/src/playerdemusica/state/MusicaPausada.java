package playerdemusica.state;

public class MusicaPausada implements EstadoDaMusica{

    @Override
    public void EstadoDaMusica() {
        System.out.println("Muscas  não esta sendo reproduzida.");
    }
}
